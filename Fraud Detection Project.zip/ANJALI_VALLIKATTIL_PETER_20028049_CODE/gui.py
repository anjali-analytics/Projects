#Importing Libraries
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import numpy as np
from pytorch_tabnet.tab_model import TabNetClassifier
import torch

# Load model
model = TabNetClassifier()
model.load_model("tabnet_fraud_detection_model.zip")


class FraudDetectionApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Credit Card Fraud Detection System")
        self.root.geometry("900x700")
        self.root.configure(bg='#e6f2ff')  # Light blue background

        # Create notebook (tabbed interface)
        style = ttk.Style()
        style.configure('TNotebook', background='#e6f2ff')
        style.configure('TNotebook.Tab',
                        background='#b3d9ff',
                        padding=[10, 5],
                        font=('Helvetica', 10, 'bold'))
        style.map('TNotebook.Tab',
                  background=[('selected', '#4da6ff')])

        self.notebook = ttk.Notebook(root, style='TNotebook')
        self.notebook.pack(fill='both', expand=True, padx=10, pady=10)

        # Create frames for tabs
        self.home_frame = tk.Frame(self.notebook, bg='#e6f2ff')
        self.prediction_frame = tk.Frame(self.notebook, bg='#e6f2ff')

        self.notebook.add(self.home_frame, text='Home')
        self.notebook.add(self.prediction_frame, text='Fraud Prediction')

        # Build UI
        self.build_home_tab()
        self.build_prediction_tab()

    def build_home_tab(self):
        container = tk.Frame(self.home_frame, bg='#e6f2ff')
        container.pack(fill='both', expand=True, padx=20, pady=20)

        title_label = tk.Label(
            container,
            text="Welcome to the Fraud Detection System",
            font=('Helvetica', 18, 'bold'),
            bg='#e6f2ff',
            fg='#004080'
        )
        title_label.pack(pady=(0, 20))

        desc_frame = tk.Frame(container, bg='#e6f2ff')
        desc_frame.pack(fill='both', expand=True)

        scrollbar = tk.Scrollbar(desc_frame)
        scrollbar.pack(side='right', fill='y')

        desc_text = """This application helps financial institutions and payment processors detect potentially fraudulent 
credit card transactions in real-time using machine learning.

How it works:
1. Go to the Fraud Prediction tab
2. Enter the transaction details in the provided text area (comma-separated values)
3. Click the 'Predict Fraud' button
4. Get an instant prediction about whether the transaction is likely fraudulent

Features:
- Real-time fraud detection
- High accuracy machine learning model
- Easy-to-use interface
- Secure processing (no data is stored)

Model Information:
The prediction model is trained on historical transaction data using a Tab transformer algorithm, 
which is known for its high accuracy in fraud detection tasks."""

        desc_label = tk.Text(
            desc_frame,
            wrap='word',
            font=('Helvetica', 11),
            bg='#e6f2ff',
            fg='#003366',
            padx=10,
            pady=10,
            yscrollcommand=scrollbar.set
        )
        desc_label.insert('1.0', desc_text)
        desc_label.config(state='disabled')
        desc_label.pack(side='left', fill='both', expand=True)

        scrollbar.config(command=desc_label.yview)

    def build_prediction_tab(self):
        container = tk.Frame(self.prediction_frame, bg='#e6f2ff')
        container.pack(fill='both', expand=True, padx=20, pady=10)

        title_label = tk.Label(
            container,
            text="Transaction Fraud Prediction",
            font=('Helvetica', 16, 'bold'),
            bg='#e6f2ff',
            fg='#004080'
        )
        title_label.pack(pady=(0, 10))

        instr_text = """Enter the transaction features below as comma-separated values (V1-V28, Amount):
Example: -1.359807, -0.072781, 2.536347, 1.378155, -0.338321, 0.462388, 0.239599, 0.098698, 0.363787, 0.090794, -0.551600, -0.617801, -0.991390, -0.311169, 1.468177, -0.470401, 0.207971, 0.025791, 0.403993, 0.251412, -0.018307, 0.277838, -0.110474, 0.066928, 0.128539, -0.189115, 0.133558, -0.021053, 149.62"""

        instr_label = tk.Label(
            container,
            text=instr_text,
            font=('Helvetica', 10),
            wraplength=800,
            justify='left',
            bg='#e6f2ff',
            fg='#003366'
        )
        instr_label.pack(pady=(0, 10))

        input_frame = tk.Frame(container, bg='#e6f2ff')
        input_frame.pack(fill='both', expand=True, pady=10)

        self.input_text = scrolledtext.ScrolledText(
            input_frame,
            width=80,
            height=10,
            font=('Courier', 10),
            bg='white',
            fg='#003366',
            insertbackground='#004080',
            padx=10,
            pady=10
        )
        self.input_text.pack(fill='both', expand=True)

        button_frame = tk.Frame(container, bg='#e6f2ff')
        button_frame.pack(pady=10)

        self.predict_button = tk.Button(
            button_frame,
            text="Predict Fraud",
            command=self.predict_fraud,
            font=('Helvetica', 12, 'bold'),
            bg='#4da6ff',
            fg='white',
            activebackground='#0073e6',
            activeforeground='white',
            relief='raised',
            borderwidth=3,
            padx=20,
            pady=5
        )
        self.predict_button.pack()

        result_container = tk.Frame(container, bg='#e6f2ff')
        result_container.pack(fill='both', expand=True, pady=10)

        self.result_label = tk.Label(
            result_container,
            text="",
            font=('Helvetica', 12, 'bold'),
            wraplength=800,
            justify='left',
            bg='#e6f2ff',
            anchor='w'
        )
        self.result_label.pack(fill='x', pady=(0, 10))

        self.risk_factors_label = tk.Label(
            result_container,
            text="",
            font=('Helvetica', 10),
            wraplength=800,
            justify='left',
            bg='#e6f2ff',
            fg='#003366',
            anchor='w'
        )
        self.risk_factors_label.pack(fill='x')

    def predict_fraud(self):
        try:
            input_data = self.input_text.get("1.0", tk.END).strip()
            if not input_data:
                messagebox.showwarning("Input Error", "Please enter transaction data")
                return

            features = [float(x.strip()) for x in input_data.split(',')]
            if len(features) != 12:
                messagebox.showwarning("Input Error", "Please enter exactly 12 values")
                return

            X = np.array(features).reshape(1, -1)

            prediction = model.predict(X)[0]
            proba = model.predict_proba(X)[0][1]

            if prediction == 1:
                self.result_label.config(
                    text=f"⚠️ High Fraud Risk Detected\nModel Probability: {proba:.2%}",
                    fg='#cc0000'
                )
            else:
                self.result_label.config(
                    text=f"✅ Low Fraud Risk\nModel Probability: {proba:.2%}",
                    fg='#009933'
                )

            risk_factors = []
            if features[-1] > 1000:
                risk_factors.append(f"High transaction amount ({features[-1]:.2f})")

            if risk_factors:
                risk_text = "Key Risk Factors:\n" + "\n".join(f"- {factor}" for factor in risk_factors)
            else:
                risk_text = "No significant risk factors identified by heuristic."

            self.risk_factors_label.config(text=risk_text)

        except ValueError as e:
            messagebox.showerror("Input Error", f"Please enter valid numbers only.\nError: {str(e)}")
        except Exception as e:
            messagebox.showerror("Error", f"An unexpected error occurred.\n{str(e)}")


if __name__ == "__main__":
    root = tk.Tk()
    app = FraudDetectionApp(root)
    root.mainloop()
